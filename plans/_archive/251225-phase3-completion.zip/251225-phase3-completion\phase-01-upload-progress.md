# Phase 3.1: Upload Progress Tracking

## Overview

Implement upload progress tracking cho better UX khi upload large files.

## Requirements

- Show upload percentage (0-100%)
- Display upload speed (MB/s)
- Show estimated time remaining (ETA)
- Handle upload errors gracefully
- Support large files (>100MB)

## Implementation

### Backend

**Option 1: Keep current endpoint, add progress events (simpler)**

- Current endpoint works fine
- Frontend uses XMLHttpRequest để track progress
- No backend changes needed

**Option 2: Chunked upload endpoint (complex, for very large files)**

- Not needed for now (YAGNI)

**Decision:** Option 1 - Frontend-only progress tracking

### Frontend

1. **Update API Client:**
   - Add `uploadWithProgress()` method using XMLHttpRequest
   - Emit progress events via callback

2. **Create Progress Component:**
   - Progress bar UI component
   - Show percentage, speed, ETA
   - Error handling

3. **Update Upload Handler:**
   - Use new upload method
   - Show progress during upload
   - Handle success/error states

## Files to Modify

- `apps/web/src/lib/api.ts` - Add uploadWithProgress method
- `apps/web/src/components/documents/document-toolbar.tsx` - Use progress
- `apps/web/src/components/ui/progress.tsx` - Create progress component (if not exists)

## Success Criteria

- ✅ Upload shows progress bar
- ✅ Percentage updates in real-time
- ✅ Speed and ETA displayed
- ✅ Works for files > 100MB
