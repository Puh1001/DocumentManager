# Phase 3.4: Sync Scheduling/Automation

## Overview

Implement automated sync scheduling để tự động sync file system với database.

## Requirements

- Configurable sync interval (default: hourly)
- Background sync execution
- Log sync results
- Manual sync still available

## Implementation

### Backend

1. **Install Dependencies:**

   ```bash
   npm install @nestjs/schedule
   ```

2. **Create Sync Scheduler:**
   - `apps/api/src/modules/storage/services/sync-scheduler.service.ts`
   - Use @Cron decorator
   - Call FolderSyncService.syncWithFileSystem()

3. **Configuration:**
   - Environment variable: `SYNC_INTERVAL` (cron expression)
   - Default: `0 * * * *` (every hour)

### Files to Create

- `apps/api/src/modules/storage/services/sync-scheduler.service.ts`

### Files to Modify

- `apps/api/src/modules/storage/storage.module.ts`
- `apps/api/src/app.module.ts` (import ScheduleModule)

## Success Criteria

- ✅ Sync runs automatically on schedule
- ✅ Configurable interval
- ✅ Logs sync results
- ✅ Manual sync still works
