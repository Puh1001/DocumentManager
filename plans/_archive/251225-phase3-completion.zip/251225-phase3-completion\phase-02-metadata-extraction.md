# Phase 3.2: Enhanced Metadata Extraction

## Overview

Enhance file metadata extraction to include more information from file system.

## Current Metadata

- ✅ fileName, fileType, fileSize
- ✅ checksum (SHA-256)
- ✅ Basic file stats

## Additional Metadata to Extract

1. **File Dates:**
   - createdAt (file creation date)
   - modifiedAt (file modification date)
   - accessedAt (optional)

2. **MIME Type:**
   - Detect from file extension + content
   - Store in database

3. **Image Dimensions (optional):**
   - Width, height for images
   - Requires image processing library

4. **Office Metadata (optional, future):**
   - Author, title, subject
   - Requires office file parsing

## Implementation

### Backend Changes

1. **Update Document Model (if needed):**
   - Add `createdAt` (from file system)
   - Add `modifiedAt` (from file system)
   - Add `mimeType` field

2. **Update DocumentService.upload():**
   - Extract file stats (already available)
   - Store createdAt, modifiedAt
   - Detect MIME type

3. **Update FolderSyncService:**
   - Extract dates when syncing existing files
   - Update document records with dates

### Files to Modify

- `apps/api/src/modules/storage/services/document.service.ts`
- `apps/api/src/modules/storage/services/folder-sync.service.ts`
- `apps/api/prisma/schema.prisma` (if adding new fields)

## Success Criteria

- ✅ File dates extracted and stored
- ✅ MIME type detected correctly
- ✅ Metadata visible in UI
