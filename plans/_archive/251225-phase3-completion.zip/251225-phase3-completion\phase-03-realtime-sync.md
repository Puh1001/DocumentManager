# Phase 3.3: Real-time Sync (WebSocket)

## Overview

Implement WebSocket-based real-time sync để auto-update folder tree khi có changes.

## Architecture

```
SMB Share → File Watcher (chokidar) → Event Emitter → WebSocket Gateway → Frontend
```

## Implementation Steps

### Step 1: Install Dependencies

```bash
cd apps/api
npm install @nestjs/websockets @nestjs/platform-socket.io socket.io
npm install chokidar @nestjs/event-emitter
npm install -D @types/chokidar
```

### Step 2: Create WebSocket Gateway

- `apps/api/src/modules/storage/gateways/folder-sync.gateway.ts`
- Handle connections
- Broadcast sync events
- JWT authentication

### Step 3: Create File Watcher Service

- `apps/api/src/modules/storage/services/folder-watcher.service.ts`
- Watch SMB base path
- Emit events on changes
- Handle errors gracefully

### Step 4: Frontend Integration

- `apps/web/src/hooks/use-folder-sync.ts`
- Connect to WebSocket
- Listen to events
- Auto-refresh folder tree

### Step 5: Update Storage Module

- Import WebSocket modules
- Register gateway and watcher service

## Files to Create

- `apps/api/src/modules/storage/gateways/folder-sync.gateway.ts`
- `apps/api/src/modules/storage/services/folder-watcher.service.ts`
- `apps/web/src/hooks/use-folder-sync.ts`

## Files to Modify

- `apps/api/src/modules/storage/storage.module.ts`
- `apps/web/src/app/dashboard/documents/page.tsx`

## Success Criteria

- ✅ File changes detected automatically
- ✅ Folder tree updates in real-time
- ✅ No manual refresh needed
- ✅ Works with multiple clients
