# Phase 3: Refactor Main Service

## Task

Refactor `FolderSyncService` to use extracted handlers while maintaining public API.

## Implementation

1. Inject handlers as dependencies
2. Delegate operations to appropriate handlers
3. Keep orchestration logic (two-pass sync flow)
4. Maintain all public methods unchanged

## Public API (unchanged)

- `syncWithFileSystem()` - Full sync
- `syncSingleFile()` - Single file sync
- `deleteSingleFile()` - Single file deletion

## Files

- Modify: `services/folder-sync.service.ts`
