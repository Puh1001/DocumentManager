# Phase 4: Update Dependencies

## Task

Update module configuration and verify all consumers work.

## Implementation

1. Add handlers to `storage.module.ts` providers
2. Verify imports in consumers:
   - `folder-sync.listener.ts`
   - `folder.controller.ts`
   - `sync-scheduler.service.ts`
3. Run compile check
4. Run tests

## Files

- Modify: `storage.module.ts`
- Verify: All consumer files
