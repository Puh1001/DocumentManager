# Phase 1: Extract Utilities

## Task

Extract `getMimeType()` method to a separate utility file.

## Implementation

1. Create `utils/mime-type.util.ts`
2. Move MIME type mapping logic
3. Update imports in `folder-sync.service.ts`

## Files

- Create: `utils/mime-type.util.ts`
- Modify: `services/folder-sync.service.ts`
