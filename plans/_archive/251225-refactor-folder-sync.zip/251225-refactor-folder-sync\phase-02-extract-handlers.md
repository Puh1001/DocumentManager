# Phase 2: Extract Handlers

## Task

Create focused handler services for different sync operations.

## Implementation

### 2.1 DocumentSyncHandler

- Extract `syncDocument()` logic
- Handle document creation/update
- Handle checksum calculation
- Handle version creation on change

### 2.2 FolderSyncHandler

- Extract folder scanning logic from `syncWithFileSystem()`
- Handle folder creation/update
- Handle recursive folder traversal

### 2.3 SyncDeletionHandler

- Extract `handleDeletedFolder()` logic
- Extract `handleDeletedDocument()` logic
- Extract `deleteSingleFile()` logic
- Handle cascade deletions

## Files

- Create: `handlers/document-sync.handler.ts`
- Create: `handlers/folder-sync.handler.ts`
- Create: `handlers/sync-deletion.handler.ts`
- Modify: `services/folder-sync.service.ts`
