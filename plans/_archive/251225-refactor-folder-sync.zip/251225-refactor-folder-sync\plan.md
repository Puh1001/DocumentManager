# Refactor FolderSyncService

## Overview

Refactor `folder-sync.service.ts` (545 lines) into smaller, focused services following Single Responsibility Principle.

## Goals

- Reduce file size to under 200 lines per file
- Improve maintainability and testability
- Keep public API unchanged (backward compatible)
- Follow YAGNI, KISS, DRY principles

## Current Structure

- `syncWithFileSystem()` - Full two-pass sync (scan + cleanup)
- `syncSingleFile()` - Real-time single file sync
- `syncDocument()` - Private document sync logic
- `handleDeletedFolder()` - Folder deletion with cascade
- `handleDeletedDocument()` - Document deletion
- `deleteSingleFile()` - Public single file deletion
- `getMimeType()` - MIME type utility

## Refactoring Strategy

### Phase 1: Extract Utilities

- Move `getMimeType()` to `utils/mime-type.util.ts`

### Phase 2: Extract Handlers

- Create `handlers/document-sync.handler.ts` - Document sync logic
- Create `handlers/folder-sync.handler.ts` - Folder sync logic
- Create `handlers/sync-deletion.handler.ts` - Deletion operations

### Phase 3: Refactor Main Service

- Keep `FolderSyncService` as orchestrator
- Delegate to handlers for specific operations
- Maintain public API compatibility

### Phase 4: Update Dependencies

- Update `storage.module.ts` imports
- Verify all consumers still work

## Files to Create

1. `utils/mime-type.util.ts` (~30 lines)
2. `handlers/document-sync.handler.ts` (~150 lines)
3. `handlers/folder-sync.handler.ts` (~100 lines)
4. `handlers/sync-deletion.handler.ts` (~80 lines)

## Files to Modify

1. `services/folder-sync.service.ts` (~200 lines, down from 545)
2. `storage.module.ts` - Add new handlers

## Success Criteria

- All files under 200 lines
- All tests pass
- No breaking changes to public API
- Code compiles without errors
