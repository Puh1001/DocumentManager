# Plan: BOSS Role Simplified UI

**Date:** 2025-12-25  
**Status:** Planning  
**Priority:** High

## Overview

Modify BOSS role UI to show only BOSS dashboard without navigation sidebar/header. BOSS users should see dashboard content directly for viewing documents.

## Requirements

1. **No Navigation for BOSS**
   - Hide Sidebar and Header for BOSS role
   - BOSS users only see BOSS dashboard content
   - Remove BOSS from sidebar navigation list

2. **Direct Dashboard Access**
   - BOSS users redirected to `/dashboard/boss` after login
   - Prevent access to other dashboard routes
   - Show department grid immediately on load

3. **Simplified Layout**
   - Create BOSS-specific layout without Sidebar/Header
   - Full-screen dashboard content
   - Keep logout functionality accessible

## Architecture

### Layout Strategy
- Create `boss/layout.tsx` to override dashboard layout
- Conditional rendering: hide Sidebar/Header for BOSS
- Alternative: separate layout route group

### Routing Changes
- Update login redirect logic for BOSS role
- Add route protection for BOSS users
- Remove BOSS nav item from sidebar

## Phases

1. **Phase 1: BOSS Layout Override** - Create layout without nav
2. **Phase 2: Login Redirect** - Redirect BOSS to dashboard
3. **Phase 3: Route Protection** - Block other routes for BOSS
4. **Phase 4: Sidebar Cleanup** - Remove BOSS from nav

## Success Criteria

- BOSS users see only BOSS dashboard (no sidebar/header)
- BOSS redirected to `/dashboard/boss` after login
- BOSS cannot access other dashboard routes
- Dashboard content displays immediately
- Logout still accessible

## Related Plans

- `20251225-1354-boss-role-ui` - Original BOSS UI implementation

