# Phase 3: Route Protection for BOSS Role

**Parent Plan:** [plan.md](./plan.md)  
**Dependencies:** Phase 1, Phase 2  
**Status:** ✅ Completed  
**Priority:** Medium

---

## Overview

Prevent BOSS users from accessing other dashboard routes. Redirect BOSS users to `/dashboard/boss` if they try to access other dashboard pages.

## Context Links

- Parent plan: [plan.md](./plan.md)
- Dashboard layout: `apps/web/src/app/[locale]/dashboard/layout.tsx`
- BOSS page: `apps/web/src/app/[locale]/dashboard/boss/page.tsx`
- Auth context: `apps/web/src/lib/auth-context.tsx`

## Key Insights

- BOSS users should only access `/dashboard/boss`
- Need route protection in dashboard layout
- Redirect on unauthorized route access
- Prevent direct URL navigation to other routes

## Requirements

1. Add route protection in dashboard layout
2. Check if user is BOSS and route is not `/boss`
3. Redirect BOSS users to `/dashboard/boss`
4. Allow non-BOSS users to access all routes
5. Handle edge cases (direct URL access, browser back)

## Architecture

### Protection Strategy

**Option A: Dashboard Layout (Recommended)**
- Add check in `dashboard/layout.tsx`
- Use `usePathname()` to get current route
- If BOSS and route !== `/dashboard/boss`, redirect

**Option B: Middleware**
- Create Next.js middleware
- Check role and route
- Redirect before page load

### Protection Logic

```typescript
// In dashboard layout
const pathname = usePathname();
const isBoss = user?.roles?.includes("boss");
const isBossRoute = pathname.includes("/dashboard/boss");

if (isBoss && !isBossRoute) {
  router.push(`/${locale}/dashboard/boss`);
}
```

## Related Code Files

- `apps/web/src/app/[locale]/dashboard/layout.tsx` - Dashboard layout
- `apps/web/src/app/[locale]/dashboard/boss/page.tsx` - BOSS page
- `apps/web/src/lib/auth-context.tsx` - Auth context

## Implementation Steps

1. **Add route check in dashboard layout**
   - Import `usePathname` from `next/navigation`
   - Check if user is BOSS
   - Check if current route is BOSS route
   - Redirect if BOSS accessing non-BOSS route

2. **Handle loading states**
   - Don't redirect during loading
   - Wait for user data to load
   - Show loading spinner during check

3. **Test route protection**
   - Test BOSS accessing `/dashboard` → redirect
   - Test BOSS accessing `/dashboard/documents` → redirect
   - Test BOSS accessing `/dashboard/boss` → allow
   - Test non-BOSS accessing routes → allow

## Todo List

- [x] Add usePathname to dashboard layout
- [x] Implement BOSS route check
- [x] Add redirect logic
- [x] Handle loading states
- [x] Test route protection
- [x] Test direct URL access
- [x] Test browser navigation

## Success Criteria

- BOSS users redirected from non-BOSS routes
- BOSS users can access `/dashboard/boss`
- Non-BOSS users can access all routes
- No redirect loops
- Works with direct URL access

## Risk Assessment

**Medium Risk:**
- Route protection logic needs careful testing
- Potential redirect loops if not handled correctly

**Considerations:**
- Ensure redirect doesn't cause infinite loop
- Handle case where BOSS route doesn't exist
- Test with browser back/forward buttons
- Consider using middleware for better performance

