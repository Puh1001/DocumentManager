# Phase 2: Login Redirect for BOSS Role

**Parent Plan:** [plan.md](./plan.md)  
**Dependencies:** Phase 1 (BOSS Layout Override)  
**Status:** ✅ Completed  
**Priority:** High

---

## Overview

Update login flow to redirect BOSS users to `/dashboard/boss` instead of `/dashboard`. Ensure BOSS users land directly on BOSS dashboard after authentication.

## Context Links

- Parent plan: [plan.md](./plan.md)
- Login page: `apps/web/src/app/[locale]/login/page.tsx`
- Auth context: `apps/web/src/lib/auth-context.tsx`
- Dashboard layout: `apps/web/src/app/[locale]/dashboard/layout.tsx`

## Key Insights

- Login redirect currently goes to `/dashboard`
- Need role-based redirect logic
- Check user roles after successful login
- Redirect before navigation completes

## Requirements

1. Update login redirect to check user role
2. Redirect BOSS users to `/dashboard/boss`
3. Redirect other users to `/dashboard`
4. Handle role check after login completes
5. Ensure redirect happens before page load

## Architecture

### Redirect Logic

```typescript
// After successful login
const user = await login(username, password);
if (user.roles?.includes("boss")) {
  router.push(`/${locale}/dashboard/boss`);
} else {
  router.push(`/${locale}/dashboard`);
}
```

### Implementation Location

**Option A: Login Page (Recommended)**
- Update `login/page.tsx` handleSubmit
- Check roles after login success
- Redirect based on role

**Option B: Auth Context**
- Add redirect logic to auth context
- Return redirect path from login
- Login page uses returned path

## Related Code Files

- `apps/web/src/app/[locale]/login/page.tsx` - Login page
- `apps/web/src/lib/auth-context.tsx` - Auth context
- `apps/web/src/app/[locale]/dashboard/boss/page.tsx` - BOSS page

## Implementation Steps

1. **Update login page redirect**
   - Modify `login/page.tsx` handleSubmit
   - After successful login, check user.roles
   - If includes "boss", redirect to `/dashboard/boss`
   - Otherwise redirect to `/dashboard`

2. **Handle role check timing**
   - Ensure user object has roles populated
   - Wait for login to complete before redirect
   - Handle edge case where roles not loaded

3. **Test redirect flow**
   - Test BOSS user login → `/dashboard/boss`
   - Test non-BOSS user login → `/dashboard`
   - Test error cases

## Todo List

- [x] Update login page redirect logic
- [x] Add role check after login
- [x] Test BOSS user redirect
- [x] Test non-BOSS user redirect
- [x] Handle edge cases (roles not loaded)

## Success Criteria

- BOSS users redirected to `/dashboard/boss` after login
- Non-BOSS users redirected to `/dashboard` after login
- Redirect happens immediately after login
- No flash of wrong page

## Risk Assessment

**Low Risk:**
- Simple redirect logic change
- No breaking changes

**Considerations:**
- Ensure roles are available immediately after login
- Handle case where roles array is empty
- Test with users having multiple roles

