# Phase 4: Sidebar Cleanup

**Parent Plan:** [plan.md](./plan.md)  
**Dependencies:** Phase 1 (BOSS Layout Override)  
**Status:** ✅ Completed  
**Priority:** Low

---

## Overview

Remove BOSS navigation item from sidebar since BOSS users won't see sidebar. Clean up sidebar code to remove BOSS-specific navigation logic.

## Context Links

- Parent plan: [plan.md](./plan.md)
- Sidebar component: `apps/web/src/components/layout/sidebar.tsx`
- BOSS layout: `apps/web/src/app/[locale]/dashboard/boss/layout.tsx`

## Key Insights

- Sidebar currently includes BOSS nav item conditionally
- BOSS users won't see sidebar (hidden in layout)
- Can remove BOSS nav item for cleaner code
- Or keep it for other roles that might need it

## Requirements

1. Remove BOSS navigation item from sidebar
2. Clean up conditional BOSS nav logic
3. Update navigation array
4. Ensure no broken references

## Architecture

### Current Sidebar Code

```typescript
// Current: BOSS nav item added conditionally
...(isBoss
  ? [
      {
        name: t("navigation.boss"),
        href: "/dashboard/boss",
        icon: Crown,
      },
    ]
  : []),
```

### Updated Sidebar Code

```typescript
// Remove BOSS nav item entirely
// BOSS users won't see sidebar anyway
```

## Related Code Files

- `apps/web/src/components/layout/sidebar.tsx` - Sidebar component
- `apps/web/messages/*/common.json` - Navigation translations

## Implementation Steps

1. **Remove BOSS nav item**
   - Remove conditional BOSS navigation from sidebar
   - Remove `isBoss` check if not used elsewhere
   - Remove `Crown` icon import if not used

2. **Clean up code**
   - Remove unused variables
   - Simplify navigation array
   - Update comments if needed

3. **Verify no impact**
   - BOSS users won't see sidebar anyway
   - Other users don't need BOSS nav item
   - No functional impact expected

## Todo List

- [x] Remove BOSS nav item from sidebar
- [x] Remove unused isBoss variable (if not needed)
- [x] Remove Crown icon import (if not used)
- [x] Test sidebar still works for other users
- [x] Verify no broken references

## Success Criteria

- BOSS nav item removed from sidebar
- Sidebar works correctly for other users
- No broken references or imports
- Code is cleaner

## Risk Assessment

**Low Risk:**
- Simple code cleanup
- BOSS users don't see sidebar anyway
- No functional impact

**Considerations:**
- Keep BOSS nav item if other roles might need it
- Consider if admin/manager should see BOSS nav
- Translation keys can remain (might be used elsewhere)

## Alternative Approach

**Keep BOSS Nav Item:**
- If other roles (admin) should access BOSS dashboard
- Keep conditional logic
- Only hide sidebar for BOSS role, not nav item

