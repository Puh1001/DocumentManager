# Phase 1: BOSS Layout Override

**Parent Plan:** [plan.md](./plan.md)  
**Dependencies:** None  
**Status:** ✅ Completed  
**Priority:** High

---

## Overview

Create BOSS-specific layout that overrides dashboard layout. Hide Sidebar and Header for BOSS role, show full-screen dashboard content.

## Context Links

- Parent plan: [plan.md](./plan.md)
- Current layout: `apps/web/src/app/[locale]/dashboard/layout.tsx`
- BOSS page: `apps/web/src/app/[locale]/dashboard/boss/page.tsx`
- Sidebar: `apps/web/src/components/layout/sidebar.tsx`
- Header: `apps/web/src/components/layout/header.tsx`

## Key Insights

- Next.js App Router supports nested layouts
- Layouts can conditionally render based on route/role
- BOSS layout should override parent dashboard layout
- Need to preserve auth checks and loading states

## Requirements

1. Create `boss/layout.tsx` to override parent layout
2. Hide Sidebar component for BOSS route
3. Hide Header component for BOSS route
4. Keep auth checks and loading states
5. Maintain full-screen content area
6. Add minimal header with logout (optional)

## Architecture

### File Structure

```
apps/web/src/app/[locale]/dashboard/
├── layout.tsx              # Parent dashboard layout (Sidebar + Header)
└── boss/
    ├── layout.tsx          # BOSS layout override (no Sidebar/Header)
    └── page.tsx            # BOSS dashboard page
```

### Layout Component

```typescript
// boss/layout.tsx
export default function BossLayout({ children }) {
  const { user, isLoading } = useAuth();
  // Only render children, no Sidebar/Header
  // Optional: minimal header with logout
}
```

### Conditional Rendering Strategy

**Option A: Separate Layout (Recommended)**

- Create `boss/layout.tsx` that doesn't render Sidebar/Header
- Next.js will use this layout for `/dashboard/boss/*` routes
- Clean separation, no conditional logic in parent

**Option B: Conditional in Parent Layout**

- Modify `dashboard/layout.tsx` to check route
- Hide Sidebar/Header if pathname includes `/boss`
- Simpler but less clean

## Related Code Files

- `apps/web/src/app/[locale]/dashboard/layout.tsx` - Parent layout
- `apps/web/src/app/[locale]/dashboard/boss/page.tsx` - BOSS page
- `apps/web/src/lib/auth-context.tsx` - Auth context

## Implementation Steps

1. **Create BOSS layout file**
   - Create `apps/web/src/app/[locale]/dashboard/boss/layout.tsx`
   - Copy auth checks from parent layout
   - Render only children (no Sidebar/Header)
   - Add full-screen container styling

2. **Add minimal header (optional)**
   - Add simple header with app name and logout
   - Or keep completely minimal (just content)

3. **Update styling**
   - Remove sidebar padding (`lg:pl-64`)
   - Full-width content area
   - Maintain responsive design

4. **Test layout override**
   - Verify BOSS route uses new layout
   - Verify other routes still use parent layout
   - Check auth redirects work

## Todo List

- [x] Create `boss/layout.tsx` file
- [x] Implement auth checks in BOSS layout
- [x] Remove Sidebar/Header rendering
- [x] Add full-screen content container
- [x] Add optional minimal header with logout
- [x] Test layout override works
- [x] Verify responsive design

## Success Criteria

- BOSS route uses BOSS layout (no Sidebar/Header)
- Other dashboard routes use parent layout
- Auth checks work correctly
- Full-screen content displays properly
- Logout accessible (if minimal header added)

## Risk Assessment

**Low Risk:**

- Layout override is standard Next.js pattern
- No breaking changes to existing routes

**Considerations:**

- Ensure auth redirects still work
- Test with different screen sizes
- Verify no layout conflicts
