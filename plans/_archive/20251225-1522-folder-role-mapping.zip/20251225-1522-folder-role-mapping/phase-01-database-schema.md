# Phase 1: Database Schema Update

**Parent Plan:** [plan.md](./plan.md)  
**Dependencies:** None  
**Status:** ✅ Completed  
**Priority:** High

## Overview

Thêm `departmentId` field vào Folder model để link folders với departments. Field này là optional để maintain backward compatibility.

## Context Links

- Parent plan: [plan.md](./plan.md)
- Research: [researcher-01-report.md](./research/researcher-01-report.md), [researcher-02-report.md](./research/researcher-02-report.md)
- Code standards: `docs/code-standards.md`

## Key Insights

- Folder model hiện tại không có departmentId
- Departments là separate entity
- Seed script tạo folders với name = department name
- Cần nullable field để support existing folders

## Requirements

1. Add `departmentId` field to Folder model (nullable)
2. Create Prisma migration
3. Update existing folders based on name matching
4. Add foreign key relationship to Department

## Architecture

### Schema Changes

```prisma
model Folder {
  // ... existing fields
  departmentId String? @map("department_id")

  department Department? @relation(fields: [departmentId], references: [id])
}

model Department {
  // ... existing fields
  folders Folder[]
}
```

### Migration Strategy

1. Add column as nullable
2. Update existing folders: match by name
3. Update seed script to set departmentId

## Related Code Files

- `apps/api/prisma/schema.prisma` - Folder model
- `apps/api/prisma/seed.ts` - Seed script
- `apps/api/src/modules/storage/services/folder.service.ts` - Folder service

## Implementation Steps

1. **Update Prisma Schema**
   - Add `departmentId` field to Folder
   - Add relation to Department
   - Add `folders` relation to Department

2. **Create Migration**
   - Generate migration with Prisma
   - Add data migration to update existing folders

3. **Update Seed Script**
   - Link folders to departments when creating
   - Set departmentId based on folder name

4. **Test Migration**
   - Verify existing folders updated correctly
   - Verify new folders get departmentId

## Todo List

- [x] Update Prisma schema
- [x] Generate migration
- [x] Create data migration script
- [x] Update seed script
- [ ] Test migration (requires applying migration first)
- [x] Verify backward compatibility

## Success Criteria

- [x] Folder model has departmentId field
- [x] Migration created (ready to apply)
- [x] Data migration script added
- [x] Seed script sets departmentId
- [x] No breaking changes (nullable field)

## Risk Assessment

- **Data Loss**: Low - field is nullable
- **Migration Time**: Medium - need to update existing data
- **Breaking Changes**: Low - optional field

## Security Considerations

- Verify foreign key constraints
- Ensure department exists before linking

## Next Steps

After completing this phase, proceed to [Phase 2: Seed Script Update](./phase-02-seed-script.md)
