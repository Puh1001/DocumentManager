# Phase 3: API Updates

**Parent Plan:** [plan.md](./plan.md)  
**Dependencies:** Phase 2 (Seed Script)  
**Status:** ✅ Completed  
**Priority:** High

## Overview

Update API endpoints và services để support filtering folders by departmentId.

## Context Links

- Parent plan: [plan.md](./plan.md)
- Dependencies: [phase-02-seed-script.md](./phase-02-seed-script.md)
- Code standards: `docs/code-standards.md`

## Key Insights

- FolderService cần support departmentId filter
- BOSS role queries cần filter by department
- Existing queries should still work (backward compatible)

## Requirements

1. Add departmentId filter to folder queries
2. Update folder service methods
3. Add departmentId to folder DTOs (optional)
4. Update folder tree endpoint

## Architecture

### Service Method Updates

```typescript
async findAll(parentId?: string, departmentId?: string) {
  return this.prisma.folder.findMany({
    where: {
      parentId: parentId || null,
      departmentId: departmentId || undefined,
      deletedAt: null,
    },
  });
}
```

### Controller Updates

```typescript
@Get('tree')
async getTree(@Query('departmentId') departmentId?: string) {
  return this.folderService.getTree(departmentId);
}
```

## Related Code Files

- `apps/api/src/modules/storage/services/folder.service.ts` - Folder service
- `apps/api/src/modules/storage/controllers/folder.controller.ts` - Folder controller
- `apps/api/src/modules/storage/dto/*` - DTOs

## Implementation Steps

1. **Update FolderService**
   - Add departmentId parameter to findAll
   - Add departmentId filter to getTree
   - Update findById to include department

2. **Update FolderController**
   - Add departmentId query parameter
   - Pass departmentId to service methods

3. **Update DTOs**
   - Add departmentId to CreateFolderDto (optional)
   - Add departmentId to response DTOs

4. **Update Tree Building**
   - Filter tree by departmentId
   - Include department info in response

## Todo List

- [x] Update FolderService methods
- [x] Add departmentId filter to queries
- [x] Update FolderController
- [x] Update DTOs
- [x] Update tree building logic
- [ ] Test API endpoints (ready to test after migration)
- [x] Verify backward compatibility (optional parameters)

## Success Criteria

- [x] Folders can be filtered by departmentId
- [x] Tree endpoint supports departmentId
- [x] Backward compatible (works without departmentId)
- [x] API code updated (ready to test after migration)

## Risk Assessment

- **Breaking Changes**: Low - optional parameter
- **Performance**: Low - simple filter

## Security Considerations

- Verify user has access to department
- Check permissions for filtered folders

## Next Steps

After completing this phase, proceed to [Phase 4: Frontend Updates](./phase-04-frontend-updates.md)
