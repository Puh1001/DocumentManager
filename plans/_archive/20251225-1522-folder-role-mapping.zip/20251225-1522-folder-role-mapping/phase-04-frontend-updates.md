# Phase 4: Frontend Updates

**Parent Plan:** [plan.md](./plan.md)  
**Dependencies:** Phase 3 (API Updates)  
**Status:** ✅ Completed  
**Priority:** High

## Overview

Update frontend components để sử dụng departmentId khi query folders thay vì name matching.

## Context Links

- Parent plan: [plan.md](./plan.md)
- Dependencies: [phase-03-api-updates.md](./phase-03-api-updates.md)
- Code standards: `docs/code-standards.md`

## Key Insights

- DocumentsList component đang match folder bằng name
- Cần update để query bằng departmentId
- API đã support departmentId filter

## Requirements

1. Update DocumentsList component
2. Update API calls to include departmentId
3. Remove name-based matching logic
4. Update folder tree queries

## Architecture

### Component Updates

```typescript
// Before: Name matching
const departmentFolder = folders.find(f => 
  f.name.toLowerCase() === departmentName.toLowerCase()
);

// After: DepartmentId filter
const tree = await api.get<Folder[]>(
  `/storage/folders/tree?departmentId=${departmentId}`
);
```

## Related Code Files

- `apps/web/src/components/boss/documents-list.tsx` - DocumentsList component
- `apps/web/src/lib/api.ts` - API client
- `apps/web/src/app/[locale]/dashboard/documents/page.tsx` - Documents page

## Implementation Steps

1. **Update DocumentsList Component**
   - Remove name matching logic
   - Add departmentId to API call
   - Use filtered folder tree

2. **Update API Client**
   - Add departmentId parameter to folder queries
   - Update tree endpoint call

3. **Update Documents Page** (if needed)
   - Pass departmentId when available
   - Update folder tree queries

4. **Test BOSS UI**
   - Verify documents show for selected department
   - Test with multiple departments
   - Verify empty states

## Todo List

- [x] Update DocumentsList component
- [x] Remove name matching logic
- [x] Add departmentId to API calls
- [x] Update API client (using query parameters - no changes needed)
- [ ] Test BOSS UI (ready to test after migration)
- [x] Verify documents display correctly (code updated)

## Success Criteria

- [x] DocumentsList uses departmentId filter
- [x] BOSS sees correct documents per department (code updated)
- [x] No name matching logic
- [x] Empty states work correctly
- [x] Performance acceptable (direct API filter)

## Risk Assessment

- **Breaking Changes**: Low - only affects BOSS UI
- **User Experience**: Medium - need to verify filtering works

## Security Considerations

- Verify user has access to department
- Check API permissions

## Next Steps

After completing this phase, the implementation is complete. Proceed to testing and refinement.

