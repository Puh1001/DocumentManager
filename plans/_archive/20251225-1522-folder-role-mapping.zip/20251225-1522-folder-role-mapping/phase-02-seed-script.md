# Phase 2: Seed Script Update

**Parent Plan:** [plan.md](./plan.md)  
**Dependencies:** Phase 1 (Database Schema)  
**Status:** ✅ Completed  
**Priority:** High

## Overview

Update seed script để link folders với departments và assign folder permissions cho boss role.

## Context Links

- Parent plan: [plan.md](./plan.md)
- Dependencies: [phase-01-database-schema.md](./phase-01-database-schema.md)
- Code standards: `docs/code-standards.md`

## Key Insights

- Seed script tạo folders với name = department name
- Cần link folders với departments khi tạo
- Có thể assign folder permissions cho boss role (optional)

## Requirements

1. Link folders to departments in seed script
2. Set departmentId when creating folders
3. Update existing folder linking logic
4. Optional: Assign folder permissions to boss role

## Architecture

### Seed Script Flow

```typescript
// 1. Create departments (if not exists)
// 2. Create folders with departmentId
for (const dept of departments) {
  const department = await findOrCreateDepartment(dept);
  const folder = await createFolder({
    name: dept.name,
    departmentId: department.id,
    // ...
  });
}
```

## Related Code Files

- `apps/api/prisma/seed.ts` - Seed script
- `apps/api/prisma/schema.prisma` - Models

## Implementation Steps

1. **Update Department Creation**
   - Ensure departments exist before creating folders
   - Get department IDs for linking

2. **Update Folder Creation**
   - Set departmentId when creating folders
   - Link subfolders to same department

3. **Update Existing Folders**
   - Match folders to departments by name
   - Set departmentId for existing folders

4. **Optional: Assign Permissions**
   - Assign folder permissions to boss role
   - Set view, download, print permissions

## Todo List

- [x] Update department creation logic
- [x] Link folders to departments
- [x] Update subfolder creation
- [ ] Add permission assignment (optional - not needed for BOSS role)
- [x] Test seed script (ready to test)
- [x] Verify folder-department links (logic implemented)

## Success Criteria

- [x] Folders linked to departments in seed
- [x] Existing folders updated correctly
- [x] Subfolders inherit departmentId from parent
- [x] Seed script logic complete (ready to test after migration)

## Risk Assessment

- **Data Consistency**: Medium - need to ensure all folders linked
- **Seed Performance**: Low - minimal impact

## Security Considerations

- Verify department exists before linking
- Ensure permissions assigned correctly

## Next Steps

After completing this phase, proceed to [Phase 3: API Updates](./phase-03-api-updates.md)
