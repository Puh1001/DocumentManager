# Research Report: Folder-Department Relationship

**Researcher:** Main Agent  
**Date:** 2025-12-25  
**Topic:** Current folder structure and department mapping

## Current State

### Folder Model
- **No direct department link**: Folder model has no `departmentId` field
- **Name-based matching**: Folders are created with name matching department name (HR, IT, etc.)
- **Path structure**: Folders use path like `HR`, `IT`, `HR/Tài liệu ISO`, etc.

### Department Model
- Separate entity with `id`, `name`, `code`
- Used for KPI records and maintenance notices
- No relationship to Folder model

### Seed Script Pattern
```typescript
// Folders created with department names
const departments = [
  { name: "HR", physicalLocation: "Tủ A, Kệ 1" },
  { name: "IT", physicalLocation: "Tủ A, Kệ 2" },
  // ...
];
// Folder path = department name
folder.path = dept.name; // "HR", "IT", etc.
```

### Current BOSS UI Issue
- `DocumentsList` component tries to match folder by name:
  ```typescript
  folder.name.toLowerCase() === departmentName.toLowerCase()
  ```
- **Problem**: Not reliable if folder name doesn't exactly match department name
- **Problem**: No way to filter folders by department for BOSS role

## Key Findings

1. **No database relationship**: Folders and Departments are separate entities
2. **Name-based matching is fragile**: Relies on exact name match
3. **Permission system exists**: `FolderPermission` can assign folders to roles
4. **BOSS has view-all**: Currently bypasses permission checks but can't filter by department

## Recommendations

1. **Add departmentId to Folder**: Direct relationship (requires migration)
2. **Use FolderPermission**: Assign department folders to "boss" role with metadata
3. **Create mapping table**: FolderDepartment mapping (flexible but adds complexity)

## Unresolved Questions

- Should we add `departmentId` to Folder model or use permission-based mapping?
- How to handle folders that belong to multiple departments?
- Should subfolders inherit department from parent?

