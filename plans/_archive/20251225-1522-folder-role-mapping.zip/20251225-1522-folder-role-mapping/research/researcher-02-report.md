# Research Report: Role-Based Folder Permissions

**Researcher:** Main Agent  
**Date:** 2025-12-25  
**Topic:** Permission system and role-based folder access

## Current Permission System

### FolderPermission Model
```prisma
model FolderPermission {
  id           String      @id
  folderId     String
  subjectType  SubjectType  // USER or ROLE
  subjectId    String       // User ID or Role ID
  permissionId String
  inherit      Boolean      @default(true)
}
```

### CASL Ability Factory
- **BOSS role**: Has `can("view", "all")` - bypasses permission checks
- **Other roles**: Load folder permissions from DB and apply
- **Inheritance**: Folder permissions apply to subfolders and documents

### Current BOSS Implementation
```typescript
if (userRoles.includes("boss")) {
  can("view", "all");
  can("download", "all");
  can("print", "all");
  return build(); // Early return - no folder filtering
}
```

## Problem Analysis

1. **BOSS sees all folders**: No way to filter by department
2. **No department context**: Permission system doesn't know about departments
3. **DocumentsList component**: Tries to match by name (unreliable)

## Solution Options

### Option 1: Add departmentId to Folder
- **Pros**: Direct relationship, simple queries
- **Cons**: Requires migration, breaks existing data structure
- **Implementation**: Add field, update seed, migrate existing folders

### Option 2: Use FolderPermission with Metadata
- **Pros**: Uses existing system, flexible
- **Cons**: Need to assign permissions for each department folder
- **Implementation**: Create permissions in seed script

### Option 3: Hybrid Approach
- Add `departmentId` to Folder (optional, nullable)
- Use FolderPermission to assign department folders to "boss" role
- Filter folders by departmentId when querying

## Recommended Approach

**Option 3 (Hybrid)**:
1. Add `departmentId` field to Folder model (nullable)
2. Update seed script to link folders with departments
3. Update BOSS UI to filter folders by departmentId
4. Keep permission system for other roles

## Implementation Considerations

- **Backward compatibility**: Existing folders without departmentId should still work
- **Migration strategy**: Update existing folders based on name matching
- **Seed script**: Link folders to departments when creating
- **API changes**: Add departmentId filter to folder queries

## Unresolved Questions

- Should we make departmentId required or optional?
- How to handle root-level folders that don't belong to any department?
- Should we add departmentId to subfolders or inherit from parent?

