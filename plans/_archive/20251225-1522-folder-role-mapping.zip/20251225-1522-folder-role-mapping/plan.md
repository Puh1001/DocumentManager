# Folder-Role Mapping for BOSS Department Documents

**Created:** 2025-12-25  
**Status:** 🔲 Planning  
**Priority:** High

## Overview

Gắn thư mục cho role để BOSS có thể xem documents của từng department khi click vào documents. Hiện tại documents không được gắn theo role, BOSS chỉ thấy tất cả folders mà không thể filter theo department.

## Problem Statement

- Folders không có relationship với Department model
- BOSS role có quyền view all nhưng không thể filter theo department
- DocumentsList component match folder bằng name (không reliable)
- Cần cách để BOSS xem documents của department cụ thể

## Solution Approach

**Hybrid Approach:**
1. Thêm `departmentId` (optional) vào Folder model
2. Update seed script để link folders với departments
3. Update BOSS UI để filter folders theo departmentId
4. Migration script để update existing folders

## Implementation Phases

1. **Phase 1: Database Schema Update**
   - Add `departmentId` field to Folder model
   - Create migration
   - Update existing folders

2. **Phase 2: Seed Script Update**
   - Link folders to departments in seed
   - Assign folder permissions to boss role

3. **Phase 3: API Updates**
   - Add departmentId filter to folder queries
   - Update folder service methods

4. **Phase 4: Frontend Updates**
   - Update DocumentsList to use departmentId
   - Fix folder filtering logic

## Research Reports

- [researcher-01-report.md](./research/researcher-01-report.md) - Folder-Department relationship
- [researcher-02-report.md](./research/researcher-02-report.md) - Role-based permissions

## Related Plans

- [20251225-1354-boss-role-ui](./20251225-1354-boss-role-ui/plan.md) - BOSS UI implementation

