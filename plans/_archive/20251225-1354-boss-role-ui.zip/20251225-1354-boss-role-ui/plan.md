# BOSS Role UI Implementation Plan

**Created:** 2025-12-25  
**Status:** 🔲 Pending  
**Estimated Duration:** 4-5 days

---

## Overview

Create a dedicated UI for BOSS role that provides hierarchical navigation:

1. Department grid (button cards)
2. View selector (KPI, Maintenance, Documents buttons)
3. List views (KPI list, Maintenance list, Documents list)
4. Detail views (KPI detail, Maintenance detail, Document detail)

## Implementation Phases

| Phase | Name                        | Status     | Files                                                                |
| ----- | --------------------------- | ---------- | -------------------------------------------------------------------- |
| 1     | BOSS Role Setup             | 🔲 Pending | [phase-01-boss-role-setup.md](./phase-01-boss-role-setup.md)         |
| 2     | BOSS Page Structure         | 🔲 Pending | [phase-02-boss-page-structure.md](./phase-02-boss-page-structure.md) |
| 3     | Department Grid View        | 🔲 Pending | [phase-03-department-grid.md](./phase-03-department-grid.md)         |
| 4     | View Selector & Navigation  | 🔲 Pending | [phase-04-view-selector.md](./phase-04-view-selector.md)             |
| 5     | List Views Implementation   | 🔲 Pending | [phase-05-list-views.md](./phase-05-list-views.md)                   |
| 6     | Detail Views Implementation | 🔲 Pending | [phase-06-detail-views.md](./phase-06-detail-views.md)               |

## Key Requirements

1. **Department Grid:**
   - Display all departments as button cards in grid layout
   - Responsive: 2 cols (mobile), 3 cols (tablet), 4 cols (desktop)
   - Click department → show view selector

2. **View Selector:**
   - 3 buttons: KPI, Maintenance, Documents
   - Click button → show corresponding list view

3. **List Views:**
   - KPI list: Filter by selected department
   - Maintenance list: Filter by selected department
   - Documents list: Filter by selected department (via folders)

4. **Detail Views:**
   - KPI detail: Reuse existing KPI detail component
   - Maintenance detail: Create detail view (or expand existing)
   - Document detail: Reuse existing document viewer

5. **Navigation:**
   - State-based navigation (not URL routing for intermediate steps)
   - Breadcrumb navigation
   - Back button functionality

## Technology Stack

- **Frontend:** Next.js 14 App Router, React, TypeScript
- **UI:** ShadcnUI components, Tailwind CSS
- **State:** React hooks (useState, useCallback)
- **API:** Existing API client (`@/lib/api`)
- **Routing:** Next.js App Router with `[locale]` prefix

## Research Reports

- [Researcher-01: Role System & UI Patterns](./research/researcher-01-report.md)
- [Researcher-02: Component Architecture & State Management](./research/researcher-02-report.md)

## Success Criteria

- [ ] BOSS role can access dedicated UI
- [ ] Department grid displays all departments
- [ ] View selector shows 3 buttons after department selection
- [ ] Each list view filters by selected department
- [ ] Detail views display correctly
- [ ] Navigation flow works smoothly
- [ ] Back button returns to previous view
- [ ] Responsive design works on all screen sizes
