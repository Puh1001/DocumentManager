# Phase 5: List Views Implementation

**Parent Plan:** [plan.md](./plan.md)  
**Dependencies:** Phase 4 (View Selector)  
**Status:** ✅ Completed  
**Priority:** High

---

## Overview

Create list views for KPI, Maintenance, and Documents that filter by selected department.

## Context Links

- Parent plan: [plan.md](./plan.md)
- Dependencies: [phase-04-view-selector.md](./phase-04-view-selector.md)
- Research: [researcher-01-report.md](./research/researcher-01-report.md), [researcher-02-report.md](./research/researcher-02-report.md)
- Code standards: `docs/code-standards.md`

## Key Insights

- KPI API: `GET /kpi/records?departmentId=...&year=...`
- Maintenance API: `GET /maintenance` (filter by departmentId in frontend)
- Documents API: Filter by department folders
- Reuse existing list components where possible

## Requirements

1. **KPI List:**
   - Fetch KPI records by department
   - Display as list/cards
   - Click item → show detail view

2. **Maintenance List:**
   - Fetch maintenance notices
   - Filter by department
   - Display as list/cards
   - Click item → show detail view

3. **Documents List:**
   - Fetch documents/folders by department
   - Display as list/cards
   - Click item → show detail view

4. **Common:**
   - Loading states
   - Error handling
   - Empty states
   - Back button to view selector

## Architecture

### Component Structure

```tsx
// KPI List
<KpiList
  departmentId={string}
  onSelectKpi={(kpiId: string) => void}
  onBack={() => void}
/>

// Maintenance List
<MaintenanceList
  departmentId={string}
  onSelectMaintenance={(maintenanceId: string) => void}
  onBack={() => void}
/>

// Documents List
<DocumentsList
  departmentId={string}
  onSelectDocument={(documentId: string) => void}
  onBack={() => void}
/>
```

### API Calls

```typescript
// KPI
const records = await api.get<KpiRecord[]>(
  `/kpi/records?departmentId=${departmentId}&year=${currentYear}`
);

// Maintenance
const notices = await api.get<MaintenanceNotice[]>("/maintenance");
const filtered = notices.filter(n => n.departmentId === departmentId);

// Documents
// Need to find documents by department folder structure
const folders = await api.get<Folder[]>("/storage/folders/tree");
// Filter by department folder
```

## Related Code Files

- `apps/web/src/app/[locale]/dashboard/kpi/page.tsx` - KPI list reference
- `apps/web/src/app/[locale]/dashboard/maintenance/page.tsx` - Maintenance list reference
- `apps/web/src/app/[locale]/dashboard/documents/page.tsx` - Documents list reference
- `apps/web/src/lib/api.ts` - API client

## Implementation Steps

1. **Create KpiList component**
   - Create `apps/web/src/components/boss/kpi-list.tsx`
   - Fetch KPI records by department
   - Display as cards/list
   - Handle item click

2. **Create MaintenanceList component**
   - Create `apps/web/src/components/boss/maintenance-list.tsx`
   - Fetch maintenance notices
   - Filter by department
   - Display as cards/list
   - Handle item click

3. **Create DocumentsList component**
   - Create `apps/web/src/components/boss/documents-list.tsx`
   - Fetch documents/folders by department
   - Display as cards/list
   - Handle item click

4. **Add common features**
   - Loading states (spinner)
   - Error handling (error message)
   - Empty states (no items message)
   - Back button

5. **Integrate in BossPage**
   - Conditional rendering based on viewType
   - Pass department and handlers
   - Update navigation state on item click

## Todo List

- [x] Create KpiList component
- [x] Create MaintenanceList component
- [x] Create DocumentsList component
- [x] Implement API calls
- [x] Add loading states
- [x] Add error handling
- [x] Add empty states
- [x] Add back buttons
- [x] Integrate in BossPage
- [x] Test each list view

## Success Criteria

- [x] KPI list displays records for selected department
- [x] Maintenance list displays notices for selected department
- [x] Documents list displays documents for selected department
- [x] Click item updates navigation state
- [x] Back button returns to view selector
- [x] Loading states work
- [x] Error handling works
- [x] Empty states display correctly

## Risk Assessment

- **API Filtering:** Documents may need special filtering logic
- **Performance:** Large lists may need pagination (future)
- **Data Structure:** Verify department relationships in API

## Security Considerations

- Verify boss role has access to all data
- Check API permissions for each endpoint

## Next Steps

After completing this phase, proceed to [Phase 6: Detail Views Implementation](./phase-06-detail-views.md)

