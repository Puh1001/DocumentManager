# Phase 3: Department Grid View

**Parent Plan:** [plan.md](./plan.md)  
**Dependencies:** Phase 2 (BOSS Page Structure)  
**Status:** ✅ Completed  
**Priority:** High

---

## Overview

Create department grid view with button cards that displays all departments in a responsive grid layout.

## Context Links

- Parent plan: [plan.md](./plan.md)
- Dependencies: [phase-02-boss-page-structure.md](./phase-02-boss-page-structure.md)
- Research: [researcher-01-report.md](./research/researcher-01-report.md)
- Code standards: `docs/code-standards.md`

## Key Insights

- Department API: `departmentApi.getAll()`
- Existing department list in `departments/page.tsx` (table format)
- Need grid layout with button cards
- Responsive: 2/3/4 columns

## Requirements

1. Fetch all departments from API
2. Display as grid of button cards
3. Responsive layout (2 cols mobile, 3 cols tablet, 4 cols desktop)
4. Click department → update navigation state
5. Show department name and code
6. Loading and error states

## Architecture

### Component Structure

```tsx
<DepartmentGrid
  departments={Department[]}
  onSelectDepartment={(dept: Department) => void}
  loading={boolean}
  error={string | null}
/>
```

### Grid Layout

```tsx
<div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
  {departments.map((dept) => (
    <Card key={dept.id} className="cursor-pointer hover:shadow-lg">
      <CardContent className="p-6">
        <h3 className="font-semibold">{dept.name}</h3>
        <p className="text-sm text-muted-foreground">{dept.code}</p>
      </CardContent>
    </Card>
  ))}
</div>
```

## Related Code Files

- `apps/web/src/app/[locale]/dashboard/departments/page.tsx` - Department list reference
- `apps/web/src/lib/api.ts` - `departmentApi.getAll()`
- `apps/web/src/components/ui/card.tsx` - Card component
- `apps/web/src/components/ui/button.tsx` - Button component

## Implementation Steps

1. **Create DepartmentGrid component**
   - Create `apps/web/src/components/boss/department-grid.tsx`
   - Accept `departments`, `onSelectDepartment`, `loading`, `error` props
   - Implement grid layout with Tailwind

2. **Fetch departments in BossPage**
   - Use `departmentApi.getAll()` in `useEffect`
   - Handle loading and error states
   - Pass data to DepartmentGrid

3. **Handle department selection**
   - On card click, call `onSelectDepartment(dept)`
   - Update navigation state in BossPage
   - Navigate to view selector

4. **Add styling**
   - Hover effects on cards
   - Active state (if needed)
   - Responsive breakpoints

5. **Add loading/error states**
   - Loading spinner
   - Error message display
   - Empty state (no departments)

## Todo List

- [x] Create DepartmentGrid component
- [x] Implement grid layout (responsive)
- [x] Fetch departments in BossPage
- [x] Handle department selection
- [x] Add loading state
- [x] Add error handling
- [x] Add empty state
- [x] Test responsive design

## Success Criteria

- [x] All departments displayed in grid
- [x] Responsive layout works (2/3/4 cols)
- [x] Click department updates navigation state
- [x] Loading state shows spinner
- [x] Error state shows message
- [x] Empty state shows message

## Risk Assessment

- **API Errors:** Handle API failures gracefully
- **Empty State:** Handle case when no departments exist
- **Performance:** Large department lists may need pagination (future)

## Security Considerations

- Verify boss role has access to all departments
- Check API permissions

## Next Steps

After completing this phase, proceed to [Phase 4: View Selector & Navigation](./phase-04-view-selector.md)

