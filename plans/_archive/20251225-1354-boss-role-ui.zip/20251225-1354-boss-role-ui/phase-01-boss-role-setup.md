# Phase 1: BOSS Role Setup

**Parent Plan:** [plan.md](./plan.md)  
**Dependencies:** None  
**Status:** ✅ Completed  
**Priority:** High

---

## Overview

Set up BOSS role in the system (if not exists) and ensure proper permissions.

## Context Links

- Parent plan: [plan.md](./plan.md)
- Research: [researcher-01-report.md](./research/researcher-01-report.md)
- Code standards: `docs/code-standards.md`
- System architecture: `docs/system-architecture.md`

## Key Insights

- Current roles: admin, manager, editor, viewer
- Roles defined in `packages/shared/src/constants/index.ts`
- Role seeding in `apps/api/prisma/seed.ts`
- Role checking: `user?.roles?.includes("boss")`

## Requirements

1. Add "boss" role to ROLES constant
2. Add boss role to seed data (if needed)
3. Define boss permissions (view all departments, KPIs, maintenance, documents)
4. Update role checking logic if needed

## Architecture

### Files to Modify

```
packages/shared/src/constants/index.ts
apps/api/prisma/seed.ts (if role doesn't exist)
```

### Role Definition

```typescript
// packages/shared/src/constants/index.ts
export const ROLES = {
  ADMIN: "admin",
  MANAGER: "manager",
  EDITOR: "editor",
  VIEWER: "viewer",
  BOSS: "boss", // New role
} as const;
```

### Permissions

BOSS role should have:

- View all departments
- View all KPIs (read-only)
- View all maintenance notices (read-only)
- View all documents (read-only)
- No write permissions (unless specified)

## Related Code Files

- `packages/shared/src/constants/index.ts` - ROLES constant
- `apps/api/prisma/seed.ts` - Role seeding
- `apps/api/src/modules/authorization/factories/casl-ability.factory.ts` - Permission factory

## Implementation Steps

1. **Add BOSS to ROLES constant**
   - Open `packages/shared/src/constants/index.ts`
   - Add `BOSS: 'boss'` to ROLES object

2. **Update seed data (if needed)**
   - Check if boss role exists in database
   - If not, add to `apps/api/prisma/seed.ts`:
     ```typescript
     { name: "boss", description: "Boss role with view access to all departments" }
     ```

3. **Update permission factory (if needed)**
   - Check `casl-ability.factory.ts`
   - Add boss permissions if custom logic needed
   - Default: Boss can view all (read-only)

4. **Test role creation**
   - Run seed script
   - Verify boss role exists in database
   - Assign boss role to test user

## Todo List

- [x] Add BOSS to ROLES constant
- [x] Add boss role to seed data
- [x] Update permission factory (if needed)
- [x] Test role creation and assignment
- [x] Verify role checking works in frontend

## Success Criteria

- [x] BOSS role exists in ROLES constant
- [x] Boss role can be assigned to users
- [x] Boss role has appropriate permissions
- [x] Role checking works: `user?.roles?.includes("boss")`

## Risk Assessment

- **Low Risk:** Adding new role is straightforward
- **Permission Issues:** Ensure boss has read access to all resources
- **Migration:** May need database migration if role doesn't exist

## Security Considerations

- Boss role should be read-only (unless business requires write access)
- Verify boss cannot access admin functions
- Ensure proper authorization checks in API endpoints

## Next Steps

After completing this phase, proceed to [Phase 2: BOSS Page Structure](./phase-02-boss-page-structure.md)
