# Phase 6: Detail Views Implementation

**Parent Plan:** [plan.md](./plan.md)  
**Dependencies:** Phase 5 (List Views)  
**Status:** ✅ Completed  
**Priority:** High

---

## Overview

Create detail views for KPI, Maintenance, and Documents that display full information when an item is clicked.

## Context Links

- Parent plan: [plan.md](./plan.md)
- Dependencies: [phase-05-list-views.md](./phase-05-list-views.md)
- Research: [researcher-01-report.md](./research/researcher-01-report.md)
- Code standards: `docs/code-standards.md`

## Key Insights

- KPI detail: Reuse existing KPI detail component from KPI page
- Maintenance detail: Create new detail view (or expand existing)
- Document detail: Reuse existing document viewer
- Back button to return to list view

## Requirements

1. **KPI Detail:**
   - Display KPI record with metrics
   - Show table and chart
   - Read-only view (boss role)

2. **Maintenance Detail:**
   - Display maintenance notice details
   - Show title, description, dates, department
   - Read-only view

3. **Document Detail:**
   - Display document viewer
   - Reuse existing document viewer component
   - Read-only view

4. **Common:**
   - Back button to list view
   - Loading states
   - Error handling

## Architecture

### Component Structure

```tsx
// KPI Detail
<KpiDetail
  kpiId={string}
  onBack={() => void}
/>

// Maintenance Detail
<MaintenanceDetail
  maintenanceId={string}
  onBack={() => void}
/>

// Document Detail
<DocumentDetail
  documentId={string}
  onBack={() => void}
/>
```

### Reuse Existing Components

- KPI: Extract KPI detail from `kpi/page.tsx`
- Document: Reuse `DocumentViewPage` component
- Maintenance: Create new detail component

## Related Code Files

- `apps/web/src/app/[locale]/dashboard/kpi/page.tsx` - KPI detail reference
- `apps/web/src/app/[locale]/dashboard/documents/[id]/view/page.tsx` - Document viewer
- `apps/web/src/app/[locale]/dashboard/maintenance/page.tsx` - Maintenance reference
- `apps/web/src/lib/api.ts` - API client

## Implementation Steps

1. **Create KpiDetail component**
   - Extract KPI detail logic from KPI page
   - Create `apps/web/src/components/boss/kpi-detail.tsx`
   - Fetch KPI record by ID
   - Display table and chart (read-only)
   - Add back button

2. **Create MaintenanceDetail component**
   - Create `apps/web/src/components/boss/maintenance-detail.tsx`
   - Fetch maintenance notice by ID
   - Display all details
   - Add back button

3. **Create DocumentDetail component**
   - Reuse existing document viewer
   - Create wrapper `apps/web/src/components/boss/document-detail.tsx`
   - Pass document ID
   - Add back button (modify viewer if needed)

4. **Add common features**
   - Loading states
   - Error handling
   - Back button functionality

5. **Integrate in BossPage**
   - Conditional rendering based on selectedItemId and viewType
   - Pass item ID and handlers
   - Update navigation state on back

## Todo List

- [x] Create KpiDetail component
- [x] Create MaintenanceDetail component
- [x] Create DocumentDetail component (wrapper)
- [x] Extract/reuse existing components
- [x] Add loading states
- [x] Add error handling
- [x] Add back buttons
- [x] Integrate in BossPage
- [x] Test each detail view

## Success Criteria

- [x] KPI detail displays correctly
- [x] Maintenance detail displays correctly
- [x] Document detail displays correctly
- [x] Back button returns to list view
- [x] Loading states work
- [x] Error handling works
- [x] Read-only mode enforced (boss role)

## Risk Assessment

- **Component Reuse:** May need to refactor existing components
- **Document Viewer:** May need modifications for back button
- **Performance:** Large documents may load slowly

## Security Considerations

- Verify boss role has read access to all details
- Check API permissions for each endpoint
- Ensure no write actions available

## Next Steps

After completing this phase, the BOSS UI implementation is complete. Proceed to testing and refinement.
