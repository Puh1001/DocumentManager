# Phase 4: View Selector & Navigation

**Parent Plan:** [plan.md](./plan.md)  
**Dependencies:** Phase 3 (Department Grid View)  
**Status:** ✅ Completed  
**Priority:** High

---

## Overview

Create view selector component that shows 3 buttons (KPI, Maintenance, Documents) after department selection.

## Context Links

- Parent plan: [plan.md](./plan.md)
- Dependencies: [phase-03-department-grid.md](./phase-03-department-grid.md)
- Research: [researcher-02-report.md](./research/researcher-02-report.md)
- Code standards: `docs/code-standards.md`

## Key Insights

- State-based navigation (not URL routing)
- Three view types: kpi, maintenance, documents
- Click button → show corresponding list view
- Back button to return to department grid

## Requirements

1. Display 3 buttons: KPI, Maintenance, Documents
2. Show selected department name
3. Click button → update navigation state
4. Back button to return to department grid
5. Icon buttons with labels
6. Responsive layout

## Architecture

### Component Structure

```tsx
<ViewSelector
  department={Department}
  onSelectView={(viewType: 'kpi' | 'maintenance' | 'documents') => void}
  onBack={() => void}
/>
```

### Button Layout

```tsx
<div className="space-y-4">
  <div className="flex items-center gap-4">
    <Button variant="ghost" onClick={onBack}>
      <ArrowLeft /> Back
    </Button>
    <h2>{department.name}</h2>
  </div>
  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
    <Button onClick={() => onSelectView("kpi")}>
      <BarChart2 /> KPI
    </Button>
    <Button onClick={() => onSelectView("maintenance")}>
      <Wrench /> Maintenance
    </Button>
    <Button onClick={() => onSelectView("documents")}>
      <FileText /> Documents
    </Button>
  </div>
</div>
```

## Related Code Files

- `apps/web/src/components/ui/button.tsx` - Button component
- `apps/web/src/components/layout/sidebar.tsx` - Icon usage reference
- `lucide-react` - Icons (BarChart2, Wrench, FileText, ArrowLeft)

## Implementation Steps

1. **Create ViewSelector component**
   - Create `apps/web/src/components/boss/view-selector.tsx`
   - Accept `department`, `onSelectView`, `onBack` props
   - Implement 3 button layout

2. **Add icons**
   - Import icons from `lucide-react`
   - BarChart2 for KPI
   - Wrench for Maintenance
   - FileText for Documents
   - ArrowLeft for Back

3. **Handle view selection**
   - On button click, call `onSelectView(viewType)`
   - Update navigation state in BossPage
   - Navigate to corresponding list view

4. **Add back button**
   - Back button clears selected department
   - Returns to department grid view

5. **Add styling**
   - Large button cards
   - Hover effects
   - Active state (if needed)

## Todo List

- [x] Create ViewSelector component
- [x] Add 3 buttons with icons
- [x] Display selected department name
- [x] Implement back button
- [x] Handle view selection
- [x] Add styling and hover effects
- [x] Test navigation flow

## Success Criteria

- [x] 3 buttons displayed correctly
- [x] Department name shown
- [x] Click button updates navigation state
- [x] Back button returns to department grid
- [x] Icons display correctly
- [x] Responsive layout works

## Risk Assessment

- **State Management:** Ensure state updates correctly
- **Navigation:** Verify back button works
- **UI/UX:** Ensure buttons are clear and intuitive

## Security Considerations

- Verify boss role has access to all view types
- Check API permissions for each view type

## Next Steps

After completing this phase, proceed to [Phase 5: List Views Implementation](./phase-05-list-views.md)
