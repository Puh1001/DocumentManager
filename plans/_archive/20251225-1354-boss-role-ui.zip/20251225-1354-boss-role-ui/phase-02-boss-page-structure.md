# Phase 2: BOSS Page Structure

**Parent Plan:** [plan.md](./plan.md)  
**Dependencies:** Phase 1 (BOSS Role Setup)  
**Status:** ✅ Completed  
**Priority:** High

---

## Overview

Create the main BOSS page structure with routing, layout, and navigation state management.

## Context Links

- Parent plan: [plan.md](./plan.md)
- Dependencies: [phase-01-boss-role-setup.md](./phase-01-boss-role-setup.md)
- Research: [researcher-02-report.md](./research/researcher-02-report.md)
- Code standards: `docs/code-standards.md`

## Key Insights

- Next.js App Router with `[locale]` prefix
- Dashboard routes: `apps/web/src/app/[locale]/dashboard/`
- State-based navigation for intermediate views
- Reuse existing dashboard layout

## Requirements

1. Create `/dashboard/boss` route
2. Add BOSS navigation item to sidebar (boss role only)
3. Create page component with state management
4. Implement navigation state (department, viewType, selectedItemId)
5. Add breadcrumb navigation

## Architecture

### File Structure

```
apps/web/src/app/[locale]/dashboard/boss/
└── page.tsx                    # Main BOSS page

apps/web/src/components/boss/
├── boss-navigation.tsx        # Navigation state context/hook
├── department-grid.tsx        # Department grid view
├── view-selector.tsx          # KPI/Maintenance/Documents buttons
├── kpi-list.tsx               # KPI list view
├── maintenance-list.tsx        # Maintenance list view
├── documents-list.tsx          # Documents list view
└── breadcrumb.tsx             # Breadcrumb navigation
```

### Navigation State

```typescript
interface BossNavigationState {
  selectedDepartment: Department | null;
  viewType: "kpi" | "maintenance" | "documents" | null;
  selectedItemId: string | null; // KPI ID, Maintenance ID, or Document ID
}
```

### Component Hierarchy

```
BossPage
├── Breadcrumb
├── DepartmentGrid (if no department selected)
├── ViewSelector (if department selected, no viewType)
├── KpiList (if viewType === 'kpi')
├── MaintenanceList (if viewType === 'maintenance')
├── DocumentsList (if viewType === 'documents')
└── DetailView (if selectedItemId exists)
```

## Related Code Files

- `apps/web/src/app/[locale]/dashboard/layout.tsx` - Dashboard layout
- `apps/web/src/components/layout/sidebar.tsx` - Sidebar navigation
- `apps/web/src/lib/auth-context.tsx` - Auth context for role checking
- `apps/web/src/lib/api.ts` - API client

## Implementation Steps

1. **Create BOSS page route**
   - Create `apps/web/src/app/[locale]/dashboard/boss/page.tsx`
   - Basic structure with state management

2. **Add sidebar navigation**
   - Update `apps/web/src/components/layout/sidebar.tsx`
   - Add BOSS navigation item (only visible for boss role)
   - Icon: `Crown` or `Building2` from lucide-react

3. **Create navigation hook**
   - Create `apps/web/src/components/boss/boss-navigation.tsx`
   - Use React Context or custom hook for state
   - Functions: `selectDepartment`, `selectView`, `selectItem`, `goBack`

4. **Create breadcrumb component**
   - Create `apps/web/src/components/boss/breadcrumb.tsx`
   - Show: Home > Department > View Type > Item (if applicable)
   - Clickable breadcrumb items

5. **Create page structure**
   - Implement conditional rendering based on state
   - Add loading states
   - Add error handling

## Todo List

- [x] Create `/dashboard/boss` route
- [x] Add BOSS to sidebar navigation (role-based)
- [x] Create navigation state management
- [x] Create breadcrumb component
- [x] Implement page structure with conditional rendering
- [x] Add loading and error states
- [x] Test navigation flow

## Success Criteria

- [x] BOSS page accessible at `/dashboard/boss`
- [x] Sidebar shows BOSS item for boss role only
- [x] Navigation state works correctly
- [x] Breadcrumb displays current location
- [x] Page structure renders correctly

## Risk Assessment

- **State Management:** Ensure state persists during navigation
- **Role Checking:** Verify boss role check works correctly
- **Routing:** Ensure no conflicts with existing routes

## Security Considerations

- Verify boss role check in page component
- Ensure unauthorized users cannot access
- Check API permissions for boss role

## Next Steps

After completing this phase, proceed to [Phase 3: Department Grid View](./phase-03-department-grid.md)
