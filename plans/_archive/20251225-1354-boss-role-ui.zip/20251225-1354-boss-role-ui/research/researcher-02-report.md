# Research Report: Component Architecture & State Management

**Researcher:** Researcher-02  
**Date:** 2025-12-25  
**Topic:** Component patterns and state management for nested navigation

## Findings

### Component Architecture

**UI Components:**

- ShadcnUI components in `apps/web/src/components/ui/`
- Button, Card, Dialog, Input, Label components available
- Consistent styling with Tailwind CSS

**Layout Components:**

- `Sidebar` - Fixed sidebar navigation
- `Header` - Top header bar
- `DashboardLayout` - Wraps all dashboard pages

**Feature Components:**

- `FolderTree` - Document folder navigation
- `DocumentList` - Document grid/list view
- `DocumentToolbar` - Document actions
- KPI components (table, chart) in KPI page
- Maintenance list components

### State Management Patterns

**Current Approach:**

- React hooks (`useState`, `useEffect`, `useCallback`)
- Custom hooks: `useAuth`, `useMaintenanceNotices`, `useFolderSync`
- API client: `api` singleton from `@/lib/api`
- Local state for UI navigation (no global state management)

**Navigation State:**

- URL-based routing for main pages
- State-based for intermediate views (e.g., selected department in KPI page)
- `useRouter` from `next/navigation` for programmatic navigation

### Grid/Button Patterns

**Department Grid Example:**

```tsx
// From departments/page.tsx
<div className="space-y-4">
  {departments.map((dept) => (
    <Card key={dept.id}>
      <div className="p-4">
        <h3>{dept.name}</h3>
        <Button onClick={() => handleSelect(dept.id)}>View</Button>
      </div>
    </Card>
  ))}
</div>
```

**Button Grid Pattern:**

- Use `grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4` for responsive grid
- Card components with hover effects
- Click handlers to update state/navigate

### Nested Navigation Patterns

**Option 1: URL-based (Deep Linking)**

- `/dashboard/boss/[departmentId]/kpi`
- `/dashboard/boss/[departmentId]/maintenance`
- `/dashboard/boss/[departmentId]/documents`
- Pros: Shareable URLs, browser back/forward
- Cons: More route files, complex routing

**Option 2: State-based (Modal/Overlay)**

- Single route: `/dashboard/boss`
- State tracks: `selectedDepartment`, `selectedView` (kpi/maintenance/documents), `selectedItemId`
- Pros: Simpler routing, smooth transitions
- Cons: No deep linking, manual back button handling

**Option 3: Hybrid**

- URL for department selection: `/dashboard/boss/[departmentId]`
- State for view type and item selection
- Pros: Balance of both approaches
- Cons: More complex implementation

### Detail View Patterns

**KPI Detail:**

- Full page view with editable table
- Chart visualization
- Export functionality
- Uses `useParams()` for ID

**Document Detail:**

- Full page viewer (`/dashboard/documents/[id]/view`)
- Permission-based actions
- Copy protection

**Maintenance Detail:**

- Currently inline in list (expandable cards)
- Could be separate detail page

### API Integration

**API Client:**

- `apps/web/src/lib/api.ts` - Centralized API client
- Methods: `get`, `post`, `patch`, `delete`, `upload`
- Automatic token refresh
- Error handling

**Data Fetching:**

- `useEffect` + `useState` for loading
- `useCallback` for memoized functions
- Loading/error states handled in components

## Recommendations

1. **Navigation Approach:**
   - Use **State-based** for BOSS UI (simpler, matches requirement)
   - Single route: `/dashboard/boss`
   - State: `selectedDepartment`, `viewType`, `selectedItemId`
   - Breadcrumb navigation for UX

2. **Component Structure:**

   ```
   BossPage
   ├── DepartmentGrid (initial view)
   ├── ViewSelector (KPI/Maintenance/Documents buttons)
   ├── ListView (KPI list / Maintenance list / Documents list)
   └── DetailView (KPI detail / Maintenance detail / Document detail)
   ```

3. **State Management:**
   - Use React Context or simple useState
   - Navigation flow: Department → View Type → List → Detail
   - Back button to go up one level

4. **Reuse Existing Components:**
   - Extract KPI table/chart components
   - Reuse Maintenance list components
   - Reuse Document list components
   - Filter by department prop

## Unresolved Questions

1. Should detail views be modals or full-page?
2. Should there be breadcrumb navigation?
3. How to handle browser back button in state-based navigation?
