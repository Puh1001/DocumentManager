# Research Report: Role System & UI Patterns

**Researcher:** Researcher-01  
**Date:** 2025-12-25  
**Topic:** Role system architecture and UI navigation patterns

## Findings

### Current Role System

**Existing Roles:**
- `admin` - System administrator with full access
- `manager` - Department manager with CRUD on assigned folders
- `editor` - Can create and edit documents
- `viewer` - View only access

**Role Definition:**
- Roles stored in `roles` table (Prisma schema)
- User-Role relationship: Many-to-many via `UserRole` junction table
- Role permissions via `RolePermission` table
- Role checking in frontend: `user?.roles?.includes("admin")` pattern

**Location:**
- `packages/shared/src/constants/index.ts` - ROLES constant
- `apps/api/prisma/schema.prisma` - Role model definition
- `apps/api/prisma/seed.ts` - Role seeding

### UI Navigation Structure

**Sidebar Navigation:**
- Defined in `apps/web/src/components/layout/sidebar.tsx`
- Navigation array with `name`, `href`, `icon` properties
- Uses `next-intl` for translations
- Active state based on pathname matching

**Routing Pattern:**
- Next.js App Router with `[locale]` prefix
- Dashboard routes: `apps/web/src/app/[locale]/dashboard/`
- Nested routes: `documents/[id]/view/page.tsx` for detail views
- Layout wrapper: `dashboard/layout.tsx` provides Sidebar + Header

**Current Dashboard Pages:**
- `/dashboard` - Home/Stats
- `/dashboard/documents` - Document browser
- `/dashboard/kpi` - KPI tracking
- `/dashboard/maintenance` - Maintenance notices
- `/dashboard/departments` - Department management
- `/dashboard/users` - User management
- `/dashboard/permissions` - Permission management

### Department UI Patterns

**Department List:**
- `apps/web/src/app/[locale]/dashboard/departments/page.tsx`
- Grid/list view with cards
- CRUD operations (admin only)
- Uses `departmentApi.getAll()` to fetch

**API:**
- `GET /departments` - List all departments
- `GET /departments/:id` - Get department details
- `POST /departments` - Create (admin)
- `PATCH /departments/:id` - Update (admin)
- `DELETE /departments/:id` - Delete (admin)

### KPI UI Patterns

**KPI Page:**
- `apps/web/src/app/[locale]/dashboard/kpi/page.tsx`
- Department selector dropdown
- KPI records list by department/year
- Detail view with editable table and charts
- Uses `api.get<KpiRecord[]>(`/kpi/records?departmentId=...&year=...`)`

**API:**
- `GET /kpi/records?departmentId=...&year=...` - List KPI records
- `GET /kpi/records/:id` - Get KPI record with metrics
- `POST /kpi/records` - Create
- `PATCH /kpi/records/:id` - Update
- `DELETE /kpi/records/:id` - Delete

### Maintenance UI Patterns

**Maintenance Page:**
- `apps/web/src/app/[locale]/dashboard/maintenance/page.tsx`
- List view with cards
- Department filtering
- CRUD operations
- Uses `maintenanceApi.getAll()` hook

**API:**
- `GET /maintenance` - List all notices
- `GET /maintenance/:id` - Get notice details
- `POST /maintenance` - Create
- `PATCH /maintenance/:id` - Update
- `DELETE /maintenance/:id` - Delete

### Documents UI Patterns

**Document List:**
- `apps/web/src/app/[locale]/dashboard/documents/page.tsx`
- Folder tree + document list
- Click document → opens detail view

**Document Detail:**
- `apps/web/src/app/[locale]/dashboard/documents/[id]/view/page.tsx`
- Full-page viewer with PDF/DOCX support
- Permission-based actions (download, print, edit)

## Recommendations

1. **BOSS Role Creation:**
   - Add "boss" role to seed data
   - Define permissions for boss role (view all departments, KPIs, maintenance, documents)
   - Update ROLES constant in shared package

2. **UI Structure:**
   - Create `/dashboard/boss` route
   - Department grid view (button cards)
   - Nested navigation: Department → [KPI, Maintenance, Documents] → Detail views
   - Use state management for navigation flow (not URL routing for intermediate steps)

3. **Component Reuse:**
   - Reuse existing KPI, Maintenance, Documents components
   - Create wrapper components for boss-specific views
   - Filter data by selected department

## Unresolved Questions

1. Should BOSS role have write permissions or read-only?
2. Should BOSS view show all departments or only assigned ones?
3. Should navigation be URL-based or state-based for intermediate views?

